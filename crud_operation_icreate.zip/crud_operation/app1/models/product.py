from django.db import models
from django.utils.timezone import now

import datetime
class Product(models.Model):
    title=models.CharField(max_length=30,blank=True,null=True)
    discription=models.TextField(blank=True,null=True)
    price=models.DecimalField(max_digits=10, decimal_places=3,blank=True,null=True)
    Create_time=models.DateTimeField(default=datetime.datetime.now ,blank=True,null=True)
#    Create_time = models.DateTimeField(auto_now_add=True)


# Create_time = models.DateTimeField(default=now)


    def __str__(self) -> str:
        return self.title
    
    def register(self):
        self.save()