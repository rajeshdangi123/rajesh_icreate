
from django.contrib import admin
from django.urls import path ,include 
from app1 import views

urlpatterns = [
    #path("",views=home,)
    path("", views.home , name="home"),
    path("read",views.read, name="read"),
    path("create" ,views.create ,name="create"),
    path("update",views.update,name="update"),
    #path("update1/int:pk>", views.update1,name="update1"),
    path("update1/<int:pk>" ,views.update1 , name="update1"),
    path("delete",views.delete, name="delete"),
    path("delete1/<int:pk>", views.delete1, name="delete1"),

]