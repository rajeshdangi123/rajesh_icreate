from django.shortcuts import render,redirect
from django.http import HttpResponse
from app1.models.product import Product
from  datetime import datetime
def home(request):
    #return HttpResponse("welcome")
    #return render (request ,"app1/home.html"),
    return render(request,"app1/home.html")



def read(request):
    pi =Product.objects.all()
    return render(request, "app1/read.html",{'pi':pi})


def create(request):
    if request.method =="GET":

        return render(request,"app1/create.html")
    else:
        postdata=request.POST
        title=postdata.get("title")
        discription=postdata.get("discription")
        price=postdata.get("price")
        #Create_time=postdata.get("Create_time")
        #print(title,discription,price,Create_time)

        my_user=Product(title=title,discription=discription,price=price)
        print(my_user)
        my_user.register()
        return redirect("read")
    return render(request,"app1/create.html")


def update(request):
    pi=Product.objects.all()
    return render(request, "app1/update.html", {"pi":pi})
# Create your views here.


def update1(request, pk):
    pi=Product.objects.get(id=pk)
    today=datetime.now()

    if request.method =="POST":
        postdata=request.POST
        title=postdata.get("title")
        discription=postdata.get("discription")
        price=postdata.get("price")

        #Create_time=postdata.get("")
        my_user=Product.objects.get(id=pk)
        my_user.title=title
        my_user.discription=discription
        my_user.price=price
        my_user.Create_time=str(today)
        my_user.save()
        return redirect('read')
    return render(request,"app1/update1.html",{"pi":pi})


def delete(request):
    pi=Product.objects.all()
    return render(request,"app1/delete.html",{"pi":pi})

def delete1(request,pk):
    pi=Product.objects.get(id=pk)
    pi.delete()
    return redirect("read")